package main

import (
	cmd "github.com/chilledblooded/gophercises/Exercise_17/cmd"
)

func main() {
	cmd.RootCmd.Execute()
}
